import { Router } from 'express';
import Match from '../models/Match.js';
import Group from '../models/Group.js';
import Category from '../models/Category.js';
import Player from '../models/Player.js';
import Tournament from '../models/Tournament.js';
import { generatePartialRoundRobin, recommendMatchesPerPlayer } from '../services/roundRobin.service.js';
import { determineMatchWinner, normalizeMatchRules, validateMatchResult } from '../services/badmintonRules.service.js';
import { buildSchedule } from '../services/scheduler.service.js';

const router = Router();

async function loadTournamentMatchRules(tournamentId) {
    const tournament = await Tournament.findById(tournamentId).select('config.matchRules').lean();
    if (!tournament) {
        return { tournament: null, rules: normalizeMatchRules() };
    }
    return {
        tournament,
        rules: normalizeMatchRules(tournament?.config?.matchRules ?? {})
    };
}

function ensureMatchResultEditable(match, res) {
    if (match.voided) {
        res.status(409).json({ error: 'Cannot modify a voided match' });
        return false;
    }
    return true;
}

function finalizeMatchResult(match, now = new Date()) {
    if (!match.actualStartAt) match.actualStartAt = now;
    if (!match.actualEndAt) match.actualEndAt = now;
    match.resultUpdatedAt = now;
    match.status = 'finished';
}

/**
 * Meccsek listázása (query paraméterekkel)
 */
router.get('/', async (req, res) => {
    const { tournamentId, groupId, categoryId, status, round } = req.query;

    const filter = {};
    if (tournamentId) filter.tournamentId = tournamentId;
    if (groupId) filter.groupId = groupId;
    if (categoryId) filter.categoryId = categoryId;
    if (status) filter.status = status;
    if (round) filter.round = round;

    const matches = await Match.find(filter)
        .sort({ startAt: 1, createdAt: 1 })
        .populate('player1', 'name')
        .populate('player2', 'name')
        .populate('winner', 'name');

    res.json(matches);
});

/**
 * Meccsek listázása group szerint (teljes lista)
 */
router.get('/group/:groupId', async (req, res) => {
    const matches = await Match.find({ groupId: req.params.groupId })
        .sort({ startAt: 1, createdAt: 1 })
        .populate('player1', 'name')
        .populate('player2', 'name')
        .populate('winner', 'name');

    res.json(matches);
});

/**
 * Meccsek generálása egy groupból (round robin)
 */
router.post('/group/:groupId', async (req, res) => {
    try {
        const group = await Group.findById(req.params.groupId);
        if (!group) return res.status(404).json({ error: 'Group not found' });

        const existing = await Match.findOne({ groupId: group._id, round: 'group' });
        if (existing) return res.status(409).json({ error: 'Group matches already generated for this group' });

        const category = await Category.findById(group.categoryId).lean();
        if (!category) return res.status(404).json({ error: 'Category not found' });

        const n = group.players.length;
        if (n < 2) return res.status(400).json({ error: 'Need at least 2 players in group' });

        const requested = Number(req.body?.matchesPerPlayer);
        const cfg = Number(category.groupStageMatchesPerPlayer);
        const m = Number.isFinite(requested) && requested > 0
            ? requested
            : (Number.isFinite(cfg) && cfg > 0 ? cfg : recommendMatchesPerPlayer(n));

        if (n % 2 === 1 && m < (n - 1) && (m % 2 === 1)) {
            return res.status(400).json({
                error: "Odd player count with partial round robin requires even matchesPerPlayer (or use full RR with matchesPerPlayer=n-1).",
                playersCount: n,
                matchesPerPlayer: m
            });
        }

        const rawMatches = generatePartialRoundRobin(group.players, m);

        const matches = await Match.insertMany(
            rawMatches.map(m => {
                const a = String(m.player1);
                const b = String(m.player2);
                const pairKey = a < b ? `${a}_${b}` : `${b}_${a}`;

                return {
                    ...m,
                    pairKey,
                    groupId: group._id,
                    tournamentId: group.tournamentId,
                    categoryId: group.categoryId,
                    round: 'group',
                    status: 'pending',
                    roundNumber: m.roundNumber ?? null,
                    drawVersion: 1,
                    resultType: 'played',
                    voided: false,
                    courtNumber: null,
                    startAt: null,
                    endAt: null,
                    sets: [],
                    winner: null
                };
            })
        );

        res.status(201).json({ generated: matches.length, matches });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/**
 * Match státusz állítás (MVP)
 */
router.patch('/:matchId/status', async (req, res) => {
    if (!req.is('application/json')) {
        return res.status(400).json({ error: 'Content-Type must be application/json' });
    }
    const { status } = req.body ?? {};
    if (!status) return res.status(400).json({ error: 'Missing status in request body' });

    if (!['pending', 'running'].includes(status)) {
        return res.status(400).json({ error: 'status must be pending or running' });
    }

    const match = await Match.findById(req.params.matchId);
    if (!match) return res.status(404).json({ error: 'Match not found' });

    if (match.voided) {
        return res.status(409).json({ error: 'Cannot change status of a voided match' });
    }

    if (match.status === 'finished') {
        return res.status(409).json({ error: 'Cannot change status of a finished match' });
    }

    if (status === 'running') {
        if (match.status !== 'pending') {
            return res.status(409).json({ error: 'Only pending can be started' });
        }
        if (!match.actualStartAt) match.actualStartAt = new Date();
    }

    if (status === 'pending') {
        if ((match.sets?.length ?? 0) > 0 || match.winner) {
            return res.status(409).json({ error: 'Cannot revert to pending when result exists' });
        }
    }

    match.status = status;
    await match.save();

    const populated = await Match.findById(match._id)
        .populate('player1', 'name')
        .populate('player2', 'name')
        .populate('winner', 'name');

    res.json(populated);
});

/**
 * Teljes meccs eredmény rögzítése (szettekkel)
 */
router.patch('/:matchId/result', async (req, res) => {
    const { sets } = req.body ?? {};

    const match = await Match.findById(req.params.matchId);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    if (!ensureMatchResultEditable(match, res)) return;

    const { tournament, rules } = await loadTournamentMatchRules(match.tournamentId);
    if (!tournament) return res.status(404).json({ error: 'Tournament not found for match' });

    const validation = validateMatchResult(sets, rules);
    if (!validation.ok) {
        return res.status(400).json({
            error: validation.error,
            set: validation.set,
            setIndex: validation.setIndex,
            rules
        });
    }

    const winner = determineMatchWinner(sets, match.player1, match.player2, rules);
    if (!winner) {
        return res.status(400).json({
            error: `No winner determined (need ${Math.floor(rules.bestOf / 2) + 1} won set${rules.bestOf > 1 ? 's' : ''})`,
            rules
        });
    }

    match.sets = sets;
    match.winner = winner;
    match.resultType = 'played';

    finalizeMatchResult(match);

    await match.save();

    const populated = await Match.findById(match._id)
        .populate('player1', 'name')
        .populate('player2', 'name')
        .populate('winner', 'name');

    res.json({ ...populated.toObject(), appliedMatchRules: rules });
});

router.patch('/:matchId/outcome', async (req, res) => {
    const { type, winnerSide } = req.body ?? {};
    if (!['wo', 'ff', 'ret'].includes(type)) {
        return res.status(400).json({ error: 'type must be wo | ff | ret' });
    }
    if (!['player1', 'player2'].includes(winnerSide)) {
        return res.status(400).json({ error: 'winnerSide must be player1 | player2' });
    }

    const match = await Match.findById(req.params.matchId);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    if (!ensureMatchResultEditable(match, res)) return;

    const winner = winnerSide === 'player1' ? match.player1 : match.player2;

    match.sets = [];
    match.winner = winner;
    match.resultType = type;

    finalizeMatchResult(match);

    await match.save();

    const populated = await Match.findById(match._id)
        .populate('player1', 'name')
        .populate('player2', 'name')
        .populate('winner', 'name');

    res.json(populated);
});

/**
 * Scheduler (MVP) - group meccsek ütemezése
 */
router.post('/group/:groupId/schedule', async (req, res) => {
    try {
        if (!req.is('application/json')) {
            return res.status(400).json({ error: 'Content-Type must be application/json' });
        }

        if (!req.body) {
            return res.status(400).json({
                error: 'Missing JSON body. Send Content-Type: application/json and a JSON payload.'
            });
        }
        const {
            startAt,
            courtsCount,
            matchMinutes,
            playerRestMinutes,
            courtTurnoverMinutes,
            breakMinutes,
            force
        } = req.body;

        const parsedStart = startAt ? new Date(startAt) : new Date();
        if (Number.isNaN(parsedStart.getTime())) {
            return res.status(400).json({ error: 'Invalid startAt' });
        }

        const cCount = Number(courtsCount ?? 1);
        const mMin = Number(matchMinutes ?? 35);

        const restMin = Number(playerRestMinutes ?? breakMinutes ?? 20);
        const turnoverMin = Number(courtTurnoverMinutes ?? 0);

        if (!Number.isInteger(cCount) || cCount < 1 || cCount > 50) {
            return res.status(400).json({ error: 'courtsCount must be an integer between 1 and 50' });
        }
        if (!Number.isFinite(mMin) || mMin <= 0 || mMin > 240) {
            return res.status(400).json({ error: 'matchMinutes must be between 1 and 240' });
        }
        if (!Number.isFinite(restMin) || restMin < 0 || restMin > 240) {
            return res.status(400).json({ error: 'playerRestMinutes must be between 0 and 240' });
        }
        if (!Number.isFinite(turnoverMin) || turnoverMin < 0 || turnoverMin > 120) {
            return res.status(400).json({ error: 'courtTurnoverMinutes must be between 0 and 120' });
        }

        const filter = {
            groupId: req.params.groupId,
            round: 'group',
            status: 'pending',
            voided: { $ne: true }
        };
        if (!force) filter.startAt = null;

        const toSchedule = await Match.find(filter)
            .select('_id player1 player2 createdAt')
            .sort({ roundNumber: 1, createdAt: 1 })
            .lean();

        if (toSchedule.length === 0) {
            return res.json({ scheduled: 0, message: 'No matches to schedule with current filter' });
        }

        // --- NEW: csak checked-in + MAIN eligible meccsek ---
        const ids = new Set();
        toSchedule.forEach(m => { ids.add(String(m.player1)); ids.add(String(m.player2)); });

        const players = await Player.find({ _id: { $in: Array.from(ids) } })
            .select('_id checkedInAt mainEligibility')
            .lean();

        const ok = new Set(
            players
                .filter(p => p.checkedInAt && p.mainEligibility === 'main')
                .map(p => String(p._id))
        );

        const filtered = toSchedule.filter(m => ok.has(String(m.player1)) && ok.has(String(m.player2)));

        if (filtered.length === 0) {
            return res.json({
                scheduled: 0,
                message: 'No schedulable matches: require both players checked-in and main-eligible'
            });
        }

        const plan = buildSchedule(filtered, {
            startAt: parsedStart,
            courtsCount: cCount,
            matchMinutes: mMin,
            playerRestMinutes: restMin,
            courtTurnoverMinutes: turnoverMin
        });

        const ops = plan.map(p => ({
            updateOne: {
                filter: { _id: p.matchId, status: 'pending' },
                update: { $set: { startAt: p.startAt, endAt: p.endAt, courtNumber: p.courtNumber } }
            }
        }));

        await Match.bulkWrite(ops);

        const updated = await Match.find({ groupId: req.params.groupId, round: 'group' })
            .sort({ startAt: 1, createdAt: 1 })
            .populate('player1', 'name')
            .populate('player2', 'name')
            .populate('winner', 'name');

        res.json({ scheduled: plan.length, matches: updated });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

/**
 * Ütemezés reset (MVP)
 */
router.patch('/group/:groupId/schedule/reset', async (req, res) => {
    try {
        const groupId = req.params.groupId;
        const filter = { groupId, round: 'group', status: 'pending', voided: { $ne: true } };

        const result = await Match.updateMany(filter, {
            $set: {
                startAt: null,
                endAt: null,
                courtNumber: null
            }
        });

        res.json({
            reset: result.modifiedCount ?? result.nModified ?? 0,
            matched: result.matchedCount ?? result.n ?? 0,
            message: 'Pending group matches schedule reset'
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;