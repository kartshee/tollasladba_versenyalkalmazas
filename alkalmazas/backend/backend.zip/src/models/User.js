import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
    {
        name: { type: String, required: true, trim: true },
        email: { type: String, required: true, trim: true, lowercase: true, unique: true, index: true },
        passwordHash: { type: String, required: true, select: false },
        role: { type: String, enum: ['admin'], default: 'admin' }
    },
    { timestamps: true }
);

export default mongoose.model('User', userSchema);
